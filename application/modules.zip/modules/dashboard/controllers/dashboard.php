<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MX_Controller {

	public function index()
	{
		if($this->session->userdata('loggedIn')==FALSE)
		{
			redirect('admin/login');	
		}
		$this->load->model('dashboard_model');

		$sensor_id     = $this->input->post('sensor_id');
		$controller_id = $this->input->post('controller_id');
		$floor_id      =  $this->input->post('floor_id');

		if(!empty($sensor_id) && !empty($controller_id) && !empty($floor_id))
		{

		$input['sensor_id']     = $sensor_id;
        $input['controller_id'] = $controller_id; 
        $input['floor_id']      = $floor_id; 
		$data['dashboard_data']     = $this->dashboard_model->log_information($input);

        }
		else{

		    $data['dashboard_data']         = $this->dashboard_model->log_information($input);
		}


		$data['result_sensor_list']     = $this->dashboard_model->dropdown_sensor_list();
		$data['result']                 = $this->dashboard_model->dropdown_floor_list();
		$data['result_controller_list'] = $this->dashboard_model->dropdown_controller_list();
	
		$this->load->view('header');
		$this->load->view('dashboard', $data);
		$this->load->view('footer');
	}
	
	public function status()
	{
		if($this->session->userdata('loggedIn')==FALSE)
		{
			redirect('admin/login');	
		}
		
		$this->load->model('dashboard_model');


		$sensor_id     = $this->input->post('sensor_id');
		$controller_id = $this->input->post('controller_id');
		$floor_id      =  $this->input->post('floor_id');

		if(!empty($sensor_id) && !empty($controller_id) && !empty($floor_id))
		{

		$input['sensor_id']     = $sensor_id;
        $input['controller_id'] = $controller_id; 
        $input['floor_id']      = $floor_id; 
       
			$data['status_data'] = $this->dashboard_model->status_info($input);

        }
		else{

		    $data['status_data']=$this->dashboard_model->status_info($input);

		}

		$data['result_sensor_list']     = $this->dashboard_model->dropdown_sensor_list();
		$data['result']                 = $this->dashboard_model->dropdown_floor_list();
		$data['result_controller_list'] = $this->dashboard_model->dropdown_controller_list();
		
		$this->load->view('header');
		$this->load->view('status', $data);
		$this->load->view('footer');
	}
	
	public function deviceinfo()
	{
		if($this->session->userdata('loggedIn')==FALSE)
		{
			redirect('admin/login');	
		}
		$this->load->model('dashboard_model');
		
		$data['dashboard_data']=$this->dashboard_model->device_info();
		
		
		$this->load->view('header');
		$this->load->view('device-info', $data);
		$this->load->view('footer');
	}	
}
