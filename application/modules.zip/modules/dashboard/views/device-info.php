
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="<?php echo base_url();?>dashboard">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Device info</li>
          </ol>

         

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              Device information</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered text-center" id="dataable" width="100%" cellspacing="0">
                  <thead>
				  
                    <tr>
                      <th>Sensor Name</th>
                      <th>Controller Name</th>
                      <th>Floor Name</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Sensor Name</th>
                      <th>Controller Name</th>
                      <th>Floor Name</th>
                    </tr>
                  </tfoot>
                  <tbody>
					         <?php foreach($dashboard_data as $dasboard_value) { ?>
					          <tr>
                      <td><?php echo $dasboard_value->sensor_name; ?></td>
                      <td><?php echo $dasboard_value->controller_name; ?></td>
                      <td><?php echo $dasboard_value->floor_name; ?></td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="card-footer small text-muted">Showing Device Information</div>
          </div>
        </div>
        <!-- /.container-fluid -->

       