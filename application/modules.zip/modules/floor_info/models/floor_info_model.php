<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Floor_info_model extends CI_Model {

/****************************
#Add Floor name
****************************/

	public function save_floor_info($floor, $floorid)
	{
		$data = array(
		    'floor_name' => $floor,
		    'floorID' => $floorid		    
		);
		$this->db->insert('tbl_floor', $data);
	}	

/****************************
#View Floor List
****************************/

 public function view_floor_list($floor)
	{
	   $query  = $this->db->query('SELECT * FROM tbl_floor ORDER BY floor_id DESC');
	   return  $query->result();
	}	

/****************************
#Delete Floor List
****************************/

	public function delete_info($id)
	{
		$result=$this->db->query("DELETE FROM  tbl_floor WHERE floor_id = $id");
	}	
/****************************
#Edit Floor List
****************************/
public function edit_info($input)
	{
		if(!empty($input['fname']) && !empty($input['floorID'])){
		$this->db->set('floor_name', $input['fname']);
		$this->db->set('floorID', $input['floorID']);
		$this->db->where('floor_id', $input['fid']);
		$result = $this->db->update('tbl_floor');
	}
	
	}	


}