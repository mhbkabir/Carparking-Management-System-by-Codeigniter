    <div id="content-wrapper">
        <div class="container-fluid">
    <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
         Parking 2
            </li>
            
          </ol>

          <div class="row">
              <div class="col-ls-12">
                  <div class="card">
                     
					<div style="position:absolute;left:50%;top:0px;width:841px;height:1190px;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">

<img src="<?php echo base_url()?>/images/background1.jpg" width="100%"></div>

<div style="position:absolute;left:508.56px;top:138.04px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:568.96px;top:138.04px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:297.42px;top:138.20px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:324.11px;top:138.46px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:351.70px;top:138.23px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:397.28px;top:138.23px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:424.56px;top:138.43px" class="cls_002"><span class="cls_002"><div class="circle2"></div></span></div>
<div style="position:absolute;left:451.96px;top:138.73px" class="cls_002"><span class="cls_002"><div class="circle2"></div></span></div>
<div style="position:absolute;left:571.75px;top:201.38px" class="cls_002"><span class="cls_002"><div class="circle2"></div></span></div>
<div style="position:absolute;left:535.12px;top:205.47px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:511.11px;top:209.92px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:486.75px;top:213.85px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:446.91px;top:221.72px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:423.06px;top:224.68px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:399.03px;top:228.56px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:335.11px;top:241.11px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:357.92px;top:237.07px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:576.00px;top:237.36px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:310.66px;top:244.47px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:514.90px;top:245.95px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:261.22px;top:251.57px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:491.68px;top:249.63px" class="cls_002"><span class="cls_002"><div class="circle3"></div></span></div>
<div style="position:absolute;left:237.32px;top:256.09px" class="cls_002"><span class="cls_002"><div class="circle3"></div></span></div>
<div style="position:absolute;left:452.50px;top:254.83px" class="cls_002"><span class="cls_002"><div class="circle3"></div></span></div>
<div style="position:absolute;left:664.61px;top:255.79px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:212.53px;top:259.67px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:428.24px;top:259.84px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:403.34px;top:264.66px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:90.09px;top:270.90px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:166.69px;top:269.51px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:363.66px;top:271.45px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:339.59px;top:275.58px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:315.55px;top:280.18px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:668.24px;top:279.53px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:263.63px;top:289.22px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:213.36px;top:296.87px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:238.18px;top:293.01px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:90.84px;top:297.37px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:670.21px;top:306.30px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:90.09px;top:324.43px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:166.69px;top:324.18px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:676.33px;top:345.28px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:91.59px;top:364.23px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:629.30px;top:360.24px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:677.92px;top:368.99px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:554.45px;top:372.81px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:520.47px;top:379.93px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:90.84px;top:391.52px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:497.21px;top:382.77px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:472.45px;top:388.48px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:683.07px;top:394.48px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:435.09px;top:395.25px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:409.81px;top:400.08px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:385.37px;top:403.62px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:91.59px;top:417.83px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:344.85px;top:410.64px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:296.66px;top:419.27px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:320.60px;top:414.27px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:635.75px;top:416.47px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:255.41px;top:426.08px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:691.78px;top:435.78px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:563.18px;top:432.04px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:504.01px;top:442.90px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:90.09px;top:455.96px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:479.42px;top:448.31px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:444.16px;top:454.06px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:693.38px;top:460.55px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:418.41px;top:458.40px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:167.19px;top:464.30px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:228.33px;top:464.30px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:393.97px;top:463.27px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:355.35px;top:469.05px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:90.84px;top:482.63px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:330.29px;top:474.29px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:643.68px;top:476.79px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:305.41px;top:480.08px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:699.16px;top:484.37px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:91.59px;top:508.44px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:707.44px;top:526.12px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:93.28px;top:545.16px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:651.75px;top:536.16px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:710.92px;top:550.88px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:166.69px;top:551.85px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:242.43px;top:552.38px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:93.28px;top:571.16px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:712.88px;top:576.66px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:94.03px;top:597.22px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>


<div style="position:absolute;left:428.74px;top:591.72px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:452.74px;top:588.72px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:490.74px;top:582.72px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:514.74px;top:577.72px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:404.43px;top:596.63px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:365.07px;top:602.43px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:341.19px;top:605.79px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:718.88px;top:615.92px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:316.24px;top:610.17px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:92.34px;top:634.48px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:522.61px;top:625.66px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:498.64px;top:630.16px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:459.66px;top:635.02px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:720.38px;top:640.82px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:166.69px;top:640.18px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:435.32px;top:639.29px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:252.06px;top:647.68px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:410.31px;top:643.27px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:92.34px;top:660.97px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:373.09px;top:651.47px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:583.85px;top:659.73px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:348.09px;top:656.03px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:323.41px;top:661.32px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:724.13px;top:666.32px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:588.25px;top:681.08px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:92.72px;top:685.79px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:591.75px;top:701.94px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:266.26px;top:712.99px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:91.22px;top:721.04px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:166.69px;top:725.41px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:266.26px;top:739.88px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:598.21px;top:739.38px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:91.22px;top:747.16px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:518.71px;top:741.88px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:493.68px;top:744.72px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:469.73px;top:749.61px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:601.39px;top:760.43px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:266.26px;top:767.57px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:428.10px;top:757.57px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:403.84px;top:761.04px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:90.22px;top:773.04px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:379.47px;top:766.44px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:606.00px;top:782.26px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:524.11px;top:789.52px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:500.96px;top:792.34px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:476.05px;top:797.23px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:348.09px;top:805.42px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:434.34px;top:806.42px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:91.22px;top:811.10px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:266.26px;top:811.03px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:410.47px;top:810.28px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:386.81px;top:815.13px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:166.69px;top:823.73px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:90.84px;top:838.04px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:266.26px;top:838.04px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:90.09px;top:863.05px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:264.26px;top:863.05px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:403.03px;top:935.98px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:470.73px;top:937.23px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:537.19px;top:936.48px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>

<div style="position:absolute;left:253.59px;top:970.98px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:294.24px;top:970.32px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:333.55px;top:970.32px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:359.16px;top:970.32px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:384.34px;top:970.07px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:423.16px;top:970.33px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:448.31px;top:971.11px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:473.62px;top:971.73px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:510.67px;top:971.73px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:536.69px;top:971.73px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:562.50px;top:972.11px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:204.09px;top:1047.85px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:230.16px;top:1047.76px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:255.84px;top:1048.60px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:295.50px;top:1048.60px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:338.00px;top:1047.95px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:363.79px;top:1047.76px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:390.47px;top:1047.85px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:429.03px;top:1047.76px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:453.84px;top:1048.60px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:479.50px;top:1047.85px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:523.78px;top:1047.95px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:548.10px;top:1048.01px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:573.90px;top:1048.01px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:616.12px;top:1046.35px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>
<div style="position:absolute;left:641.87px;top:1046.35px" class="cls_002"><span class="cls_002"><div class="circle"></div></span></div>

</div>

					 
					 
					 
					 
					 
					 
					 
                  </div>
              </div>
          </div>
  </div>
</div>


