    <div id="content-wrapper">
        <div class="container-fluid">
    <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
         Parking 2
            </li>
            
          </ol>
			<div class="row">
				<div class="col-md-8">
					<img src="<?php echo base_url()?>images/direction.jpg" style="float:right;">
				</div>
			</div>
			   
          <div class="row">
              <div class="col-ls-12">
                  <div class="card" style="border:0">
						<div style="position:absolute;left:50%;top:0px;width:841px;height:1290px;">
						
						<div style="position:absolute;left:0px;top:0px">
						<img src="<?php echo base_url()?>images/floor2.jpg" width=841 height=1190></div>

						<div style="position:absolute;left:508.56px;top:59.04px" class="cls_002"><span class="cls_002"><?php echo $sensor_76; ?></span></div>
						
						<div style="position:absolute;left:568.96px;top:59.04px" class="cls_002"><span class="cls_002"><?php echo $sensor_75; ?></span></div>
						<div style="position:absolute;left:296.42px;top:59.20px" class="cls_002"><span class="cls_002"><?php echo $sensor_82; ?></span></div>
						<div style="position:absolute;left:323.11px;top:59.46px" class="cls_002"><span class="cls_002"><?php echo $sensor_81; ?></span></div>
						<div style="position:absolute;left:351.70px;top:59.23px" class="cls_002"><span class="cls_002"><?php echo $sensor_80; ?></div></span></div>
						<div style="position:absolute;left:397.28px;top:59.23px" class="cls_002"><span class="cls_002"><?php echo $sensor_79; ?></span></div>
						<div style="position:absolute;left:424.56px;top:59.43px" class="cls_002"><span class="cls_002"><?php echo $sensor_78; ?></span></div>
						<div style="position:absolute;left:451.96px;top:59.73px" class="cls_002"><span class="cls_002"><?php echo $sensor_77; ?></span></div>
						<div style="position:absolute;left:571.75px;top:127.38px" class="cls_002"><span class="cls_002"><?php echo $sensor_74; ?></span></div>
						<div style="position:absolute;left:535.12px;top:132.47px" class="cls_002"><span class="cls_002"><?php echo $sensor_73; ?></span></div>
						<div style="position:absolute;left:511.11px;top:136.92px" class="cls_002"><span class="cls_002"><?php echo $sensor_72; ?></span></div>
						<div style="position:absolute;left:486.75px;top:140.85px" class="cls_002"><span class="cls_002"><?php echo $sensor_71; ?></span></div>
						<div style="position:absolute;left:444.91px;top:149.72px" class="cls_002"><span class="cls_002"><?php echo $sensor_70; ?></span></div>
						<div style="position:absolute;left:422.06px;top:153.68px" class="cls_002"><span class="cls_002"><?php echo $sensor_69; ?></span></div>
						<div style="position:absolute;left:398.03px;top:157.56px" class="cls_002"><span class="cls_002"><?php echo $sensor_68; ?></span></div>
						<div style="position:absolute;left:334.11px;top:169.11px" class="cls_002"><span class="cls_002"><?php echo $sensor_66; ?></span></div>
						<div style="position:absolute;left:356.92px;top:164.07px" class="cls_002"><span class="cls_002"><?php echo $sensor_67; ?></span></div>
						<div style="position:absolute;left:576.00px;top:166.36px" class="cls_002"><span class="cls_002"><?php echo $sensor_56; ?></span></div>
						<div style="position:absolute;left:310.66px;top:172.47px" class="cls_002"><span class="cls_002"><?php echo $sensor_65; ?></span></div>
						<div style="position:absolute;left:514.90px;top:177.95px" class="cls_002"><span class="cls_002"><?php echo $sensor_57; ?></span></div>
						<div style="position:absolute;left:259.22px;top:183.57px" class="cls_002"><span class="cls_002"><?php echo $sensor_4; ?></span></div>
						<div style="position:absolute;left:491.68px;top:181.63px" class="cls_002"><span class="cls_002"><?php echo $sensor_58; ?></span></div>
						<div style="position:absolute;left:235.32px;top:188.09px" class="cls_002"><span class="cls_002"><?php echo $sensor_3; ?></span></div>
						<div style="position:absolute;left:452.50px;top:190.83px" class="cls_002"><span class="cls_002"><?php echo $sensor_59; ?></span></div>
						<div style="position:absolute;left:664.61px;top:190.79px" class="cls_002"><span class="cls_002"><?php echo $sensor_55; ?></span></div>
						<div style="position:absolute;left:209.53px;top:191.67px" class="cls_002"><span class="cls_002"><?php echo $sensor_2; ?></span></div>
						<div style="position:absolute;left:428.24px;top:195.84px" class="cls_002"><span class="cls_002"><?php echo $sensor_60; ?></span></div>
						<div style="position:absolute;left:403.34px;top:200.66px" class="cls_002"><span class="cls_002"><?php echo $sensor_61; ?></span></div>
						<div style="position:absolute;left:90.09px;top:207.90px" class="cls_002"><span class="cls_002"><?php echo $sensor_83; ?></span></div>
						<div style="position:absolute;left:166.69px;top:200.51px" class="cls_002"><span class="cls_002"><?php echo $sensor_1; ?></span></div>
						<div style="position:absolute;left:363.66px;top:207.45px" class="cls_002"><span class="cls_002"><?php echo $sensor_62; ?></span></div>
						<div style="position:absolute;left:339.59px;top:213.58px" class="cls_002"><span class="cls_002"><?php echo $sensor_63; ?></span></div>
						<div style="position:absolute;left:315.55px;top:219.18px" class="cls_002"><span class="cls_002"><?php echo $sensor_64; ?></span></div>
						<div style="position:absolute;left:668.24px;top:221.53px" class="cls_002"><span class="cls_002"><?php echo $sensor_54; ?></span></div>
						<div style="position:absolute;left:261.63px;top:228.22px" class="cls_002"><span class="cls_002"><?php echo $sensor_8; ?></span></div>
						<div style="position:absolute;left:211.36px;top:235.87px" class="cls_002"><span class="cls_002"><?php echo $sensor_6; ?></span></div>
						<div style="position:absolute;left:237.18px;top:233.01px" class="cls_002"><span class="cls_002"><?php echo $sensor_7; ?></span></div>
						<div style="position:absolute;left:90.84px;top:239.37px" class="cls_002"><span class="cls_002"><?php echo $sensor_84; ?></span></div>
						<div style="position:absolute;left:670.21px;top:250.30px" class="cls_002"><span class="cls_002"><?php echo $sensor_53; ?></span></div>
						<div style="position:absolute;left:90.09px;top:270.43px" class="cls_002"><span class="cls_002"><?php echo $sensor_85; ?></span></div>
						<div style="position:absolute;left:165.69px;top:257.18px" class="cls_002"><span class="cls_002"><?php echo $sensor_5; ?></span></div>
						<div style="position:absolute;left:676.33px;top:296.28px" class="cls_002"><span class="cls_002"><?php echo $sensor_52; ?></span></div>
						<div style="position:absolute;left:91.59px;top:315.23px" class="cls_002"><span class="cls_002"><?php echo $sensor_86; ?></span></div>
						<div style="position:absolute;left:629.30px;top:307.24px" class="cls_002"><span class="cls_002"><?php echo $sensor_37; ?></span></div>
						<div style="position:absolute;left:679.92px;top:323.99px" class="cls_002"><span class="cls_002"><?php echo $sensor_51; ?></span></div>
						<div style="position:absolute;left:553.45px;top:319.81px" class="cls_002"><span class="cls_002"><?php echo $sensor_36; ?></span></div>
						<div style="position:absolute;left:519.47px;top:326.93px" class="cls_002"><span class="cls_002"><?php echo $sensor_18; ?></span></div>
						<div style="position:absolute;left:90.84px;top:346.52px" class="cls_002"><span class="cls_002"><?php echo $sensor_87; ?></span></div>
						<div style="position:absolute;left:496.21px;top:331.77px" class="cls_002"><span class="cls_002"><?php echo $sensor_17; ?></span></div>
						<div style="position:absolute;left:470.45px;top:336.48px" class="cls_002"><span class="cls_002"><?php echo $sensor_16; ?></span></div>
						<div style="position:absolute;left:683.07px;top:350.48px" class="cls_002"><span class="cls_002"><?php echo $sensor_50; ?></span></div>
						<div style="position:absolute;left:434.09px;top:345.25px" class="cls_002"><span class="cls_002"><?php echo $sensor_15; ?></span></div>
						<div style="position:absolute;left:409.81px;top:351.08px" class="cls_002"><span class="cls_002"><?php echo $sensor_14; ?></span></div>
						<div style="position:absolute;left:384.37px;top:355.62px" class="cls_002"><span class="cls_002"><?php echo $sensor_13; ?></span></div>
						<div style="position:absolute;left:91.59px;top:377.83px" class="cls_002"><span class="cls_002"><?php echo $sensor_88; ?></span></div>
						<div style="position:absolute;left:342.85px;top:365.64px" class="cls_002"><span class="cls_002"><?php echo $sensor_12; ?></span></div>
						<div style="position:absolute;left:294.66px;top:375.27px" class="cls_002"><span class="cls_002"><?php echo $sensor_10; ?></span></div>
						<div style="position:absolute;left:319.60px;top:370.27px" class="cls_002"><span class="cls_002"><?php echo $sensor_11; ?></span></div>
						<div style="position:absolute;left:635.75px;top:372.47px" class="cls_002"><span class="cls_002"><?php echo $sensor_38; ?></span></div>
						<div style="position:absolute;left:253.41px;top:384.08px" class="cls_002"><span class="cls_002"><?php echo $sensor_9; ?></span></div>
						<div style="position:absolute;left:691.78px;top:397.78px" class="cls_002"><span class="cls_002"><?php echo $sensor_49; ?></span></div>
						<div style="position:absolute;left:563.18px;top:388.04px" class="cls_002"><span class="cls_002"><?php echo $sensor_35; ?></span></div>
						<div style="position:absolute;left:504.01px;top:402.90px" class="cls_002"><span class="cls_002"><?php echo $sensor_19; ?></span></div>
						<div style="position:absolute;left:90.09px;top:420.96px" class="cls_002"><span class="cls_002"><?php echo $sensor_89; ?></span></div>
						<div style="position:absolute;left:478.42px;top:407.31px" class="cls_002"><span class="cls_002"><?php echo $sensor_20; ?></span></div>
						<div style="position:absolute;left:442.16px;top:416.06px" class="cls_002"><span class="cls_002"><?php echo $sensor_21; ?></span></div>
						<div style="position:absolute;left:694.38px;top:427.55px" class="cls_002"><span class="cls_002"><?php echo $sensor_48; ?></span></div>
						<div style="position:absolute;left:418.41px;top:420.40px" class="cls_002"><span class="cls_002"><?php echo $sensor_22; ?></span></div>
						<div style="position:absolute;left:165.19px;top:426.30px" class="cls_002"><span class="cls_002"><?php echo $sensor_134; ?></span></div>
						<div style="position:absolute;left:226.33px;top:426.30px" class="cls_002"><span class="cls_002"><?php echo $sensor_135; ?></span></div>
						<div style="position:absolute;left:391.97px;top:426.27px" class="cls_002"><span class="cls_002"><?php echo $sensor_23; ?></span></div>
						<div style="position:absolute;left:353.35px;top:436.05px" class="cls_002"><span class="cls_002"><?php echo $sensor_24; ?></span></div>
						<div style="position:absolute;left:90.84px;top:450.63px" class="cls_002"><span class="cls_002"><?php echo $sensor_90; ?></span></div>
						<div style="position:absolute;left:328.29px;top:440.29px" class="cls_002"><span class="cls_002"><?php echo $sensor_25; ?></span></div>
						<div style="position:absolute;left:643.68px;top:439.79px" class="cls_002"><span class="cls_002"><?php echo $sensor_39; ?></span></div>
						<div style="position:absolute;left:304.41px;top:444.08px" class="cls_002"><span class="cls_002"><?php echo $sensor_26; ?></span></div>
						<div style="position:absolute;left:699.16px;top:455.37px" class="cls_002"><span class="cls_002"><?php echo $sensor_47; ?></span></div>
						<div style="position:absolute;left:91.59px;top:481.44px" class="cls_002"><span class="cls_002"><?php echo $sensor_91; ?></span></div>
						<div style="position:absolute;left:707.44px;top:502.12px" class="cls_002"><span class="cls_002"><?php echo $sensor_46; ?></span></div>
						<div style="position:absolute;left:93.28px;top:523.16px" class="cls_002"><span class="cls_002"><?php echo $sensor_92; ?></span></div>
						<div style="position:absolute;left:651.75px;top:511.16px" class="cls_002"><span class="cls_002"><?php echo $sensor_40; ?></span></div>
						<div style="position:absolute;left:710.92px;top:529.88px" class="cls_002"><span class="cls_002"><?php echo $sensor_45; ?></span></div>
						<div style="position:absolute;left:165.69px;top:528.85px" class="cls_002"><span class="cls_002"><?php echo $sensor_133; ?></span></div>
						<div style="position:absolute;left:239.43px;top:526.38px" class="cls_002"><span class="cls_002"><?php echo $sensor_136; ?></span></div>
						<div style="position:absolute;left:93.28px;top:553.16px" class="cls_002"><span class="cls_002"><?php echo $sensor_93; ?></span></div>
						<div style="position:absolute;left:713.88px;top:558.66px" class="cls_002"><span class="cls_002"><?php echo $sensor_44; ?></span></div>
						<div style="position:absolute;left:94.03px;top:581.22px" class="cls_002"><span class="cls_002"><?php echo $sensor_94; ?></span></div>


						<div style="position:absolute;left:428.74px;top:573.72px" class="cls_002"><span class="cls_002"><?php echo $sensor_31; ?></span></div>
						<div style="position:absolute;left:451.74px;top:568.72px" class="cls_002"><span class="cls_002"><?php echo $sensor_32; ?></span></div>
						<div style="position:absolute;left:489.74px;top:564.72px" class="cls_002"><span class="cls_002"><?php echo $sensor_33; ?></span></div>
						<div style="position:absolute;left:513.74px;top:560.72px" class="cls_002"><span class="cls_002"><?php echo $sensor_34; ?></span></div>
						<div style="position:absolute;left:402.43px;top:578.63px" class="cls_002"><span class="cls_002"><?php echo $sensor_30; ?></span></div>
						<div style="position:absolute;left:365.07px;top:584.43px" class="cls_002"><span class="cls_002"><?php echo $sensor_29; ?></span></div>
						<div style="position:absolute;left:339.19px;top:587.79px" class="cls_002"><span class="cls_002"><?php echo $sensor_28; ?></span></div>
						<div style="position:absolute;left:720.88px;top:603.92px" class="cls_002"><span class="cls_002"><?php echo $sensor_43; ?></span></div>
						<div style="position:absolute;left:315.24px;top:593.17px" class="cls_002"><span class="cls_002"><?php echo $sensor_27; ?></span></div>
						<div style="position:absolute;left:92.34px;top:625.48px" class="cls_002"><span class="cls_002"><?php echo $sensor_95; ?></span></div>
						<div style="position:absolute;left:521.61px;top:612.66px" class="cls_002"><span class="cls_002"><?php echo $sensor_145; ?></span></div>
						<div style="position:absolute;left:497.64px;top:617.16px" class="cls_002"><span class="cls_002"><?php echo $sensor_144; ?></span></div>
						<div style="position:absolute;left:458.66px;top:622.02px" class="cls_002"><span class="cls_002"><?php echo $sensor_143; ?></span></div>
						<div style="position:absolute;left:726.38px;top:632.82px" class="cls_002"><span class="cls_002"><?php echo $sensor_42; ?></span></div>
						<div style="position:absolute;left:166.69px;top:628.18px" class="cls_002"><span class="cls_002"><?php echo $sensor_132; ?></span></div>
						<div style="position:absolute;left:435.32px;top:626.29px" class="cls_002"><span class="cls_002"><?php echo $sensor_142; ?></span></div>
						<div style="position:absolute;left:251.06px;top:636.68px" class="cls_002"><span class="cls_002"><?php echo $sensor_137; ?></span></div>
						<div style="position:absolute;left:410.31px;top:631.27px" class="cls_002"><span class="cls_002"><?php echo $sensor_141; ?></span></div>
						<div style="position:absolute;left:92.34px;top:653.97px" class="cls_002"><span class="cls_002"><?php echo $sensor_96; ?></span></div>
						<div style="position:absolute;left:372.09px;top:640.47px" class="cls_002"><span class="cls_002"><?php echo $sensor_140; ?></span></div>
						<div style="position:absolute;left:583.85px;top:653.73px" class="cls_002"><span class="cls_002"><?php echo $sensor_146; ?></span></div>
						<div style="position:absolute;left:347.09px;top:647.03px" class="cls_002"><span class="cls_002"><?php echo $sensor_139; ?></span></div>
			
						<div style="position:absolute;left:322.41px;top:653.32px" class="cls_002"><span class="cls_002"><?php echo $sensor_138; ?></span></div>
						<div style="position:absolute;left:731.13px;top:661.32px" class="cls_002"><span class="cls_002"><?php echo $sensor_41; ?></span></div>
						<div style="position:absolute;left:588.25px;top:678.08px" class="cls_002"><span class="cls_002"><?php echo $sensor_147; ?></span></div>
						<div style="position:absolute;left:92.72px;top:683.79px" class="cls_002"><span class="cls_002"><?php echo $sensor_97; ?></span></div>
						<div style="position:absolute;left:591.75px;top:701.94px" class="cls_002"><span class="cls_002"><?php echo $sensor_148; ?></span></div>
						<div style="position:absolute;left:266.26px;top:713.99px" class="cls_002"><span class="cls_002"><?php echo $sensor_165; ?></span></div>
						<div style="position:absolute;left:91.22px;top:724.04px" class="cls_002"><span class="cls_002"><?php echo $sensor_98; ?></span></div>
						<div style="position:absolute;left:166.69px;top:725.41px" class="cls_002"><span class="cls_002"><?php echo $sensor_131; ?></span></div>
						<div style="position:absolute;left:266.26px;top:745.88px" class="cls_002"><span class="cls_002"><?php echo $sensor_166; ?></span></div>
						<div style="position:absolute;left:598.21px;top:745.38px" class="cls_002"><span class="cls_002"><?php echo $sensor_149; ?></span></div>
						<div style="position:absolute;left:91.22px;top:754.16px" class="cls_002"><span class="cls_002"><?php echo $sensor_99; ?></span></div>
						<div style="position:absolute;left:517.71px;top:745.88px" class="cls_002"><span class="cls_002"><?php echo $sensor_164; ?></span></div>
						<div style="position:absolute;left:493.68px;top:749.72px" class="cls_002"><span class="cls_002"><?php echo $sensor_163; ?></span></div>
						<div style="position:absolute;left:468.73px;top:753.61px" class="cls_002"><span class="cls_002"><?php echo $sensor_162; ?></span></div>
						<div style="position:absolute;left:601.39px;top:769.43px" class="cls_002"><span class="cls_002"><?php echo $sensor_150; ?></span></div>
						<div style="position:absolute;left:266.26px;top:776.57px" class="cls_002"><span class="cls_002"><?php echo $sensor_167; ?></span></div>
						<div style="position:absolute;left:426.10px;top:763.57px" class="cls_002"><span class="cls_002"><?php echo $sensor_161; ?></span></div>
						<div style="position:absolute;left:402.84px;top:769.04px" class="cls_002"><span class="cls_002"><?php echo $sensor_160; ?></span></div>
						<div style="position:absolute;left:90.22px;top:784.04px" class="cls_002"><span class="cls_002"><?php echo $sensor_100; ?></span></div>
						<div style="position:absolute;left:378.47px;top:773.44px" class="cls_002"><span class="cls_002"><?php echo $sensor_159; ?></span></div>
						<div style="position:absolute;left:606.00px;top:794.26px" class="cls_002"><span class="cls_002"><?php echo $sensor_151; ?></span></div>
						<div style="position:absolute;left:524.11px;top:800.52px" class="cls_002"><span class="cls_002"><?php echo $sensor_152; ?></span></div>
						<div style="position:absolute;left:499.96px;top:804.34px" class="cls_002"><span class="cls_002"><?php echo $sensor_153; ?></span></div>
						<div style="position:absolute;left:475.05px;top:810.23px" class="cls_002"><span class="cls_002"><?php echo $sensor_154; ?></span></div>
						<div style="position:absolute;left:347.09px;top:814.42px" class="cls_002"><span class="cls_002"><?php echo $sensor_158; ?></span></div>
						<div style="position:absolute;left:432.34px;top:819.42px" class="cls_002"><span class="cls_002"><?php echo $sensor_155; ?></span></div>
						<div style="position:absolute;left:91.22px;top:827.10px" class="cls_002"><span class="cls_002"><?php echo $sensor_101; ?></span></div>
						<div style="position:absolute;left:266.26px;top:828.03px" class="cls_002"><span class="cls_002"><?php echo $sensor_168; ?></span></div>
						<div style="position:absolute;left:408.47px;top:824.28px" class="cls_002"><span class="cls_002"><?php echo $sensor_156; ?></span></div>
						<div style="position:absolute;left:384.81px;top:828.13px" class="cls_002"><span class="cls_002"><?php echo $sensor_157; ?></span></div>
						<div style="position:absolute;left:165.69px;top:836.73px" class="cls_002"><span class="cls_002"><?php echo $sensor_130; ?></span></div>
						<div style="position:absolute;left:90.84px;top:858.04px" class="cls_002"><span class="cls_002"><?php echo $sensor_102; ?></span></div>
						<div style="position:absolute;left:266.26px;top:858.04px" class="cls_002"><span class="cls_002"><?php echo $sensor_169; ?></span></div>
						<div style="position:absolute;left:90.09px;top:888.05px" class="cls_002"><span class="cls_002"><?php echo $sensor_103; ?></span></div>
						<div style="position:absolute;left:264.26px;top:888.05px" class="cls_002"><span class="cls_002"><?php echo $sensor_170; ?></span></div>
						<div style="position:absolute;left:403.03px;top:969.98px" class="cls_002"><span class="cls_002"><?php echo $sensor_171; ?></span></div>
						<div style="position:absolute;left:470.73px;top:970.23px" class="cls_002"><span class="cls_002"><?php echo $sensor_172; ?></span></div>
						<div style="position:absolute;left:537.19px;top:970.48px" class="cls_002"><span class="cls_002"><?php echo $sensor_173; ?></span></div>

						<div style="position:absolute;left:253.59px;top:1002.98px" class="cls_002"><span class="cls_002"><?php echo $sensor_129; ?></span></div>
						<div style="position:absolute;left:294.24px;top:1002.32px" class="cls_002"><span class="cls_002"><?php echo $sensor_128; ?></span></div>
						<div style="position:absolute;left:333px;top:1003.32px" class="cls_002"><span class="cls_002"><?php echo $sensor_127; ?></span></div>
						<div style="position:absolute;left:358.16px;top:1002.32px" class="cls_002"><span class="cls_002"><?php echo $sensor_126; ?></span></div>
						<div style="position:absolute;left:383px;top:1002.07px" class="cls_002"><span class="cls_002"><?php echo $sensor_125; ?></span></div>
						<div style="position:absolute;left:423.16px;top:1002.33px" class="cls_002"><span class="cls_002"><?php echo $sensor_124; ?></span></div>
						<div style="position:absolute;left:448.31px;top:1002.11px" class="cls_002"><span class="cls_002"><?php echo $sensor_123; ?></span></div>
						<div style="position:absolute;left:473px;top:1002.73px" class="cls_002"><span class="cls_002"><?php echo $sensor_122; ?></span></div>
						<div style="position:absolute;left:510.67px;top:1002.73px" class="cls_002"><span class="cls_002"><?php echo $sensor_121; ?></span></div>
						<div style="position:absolute;left:536px;top:1002.73px" class="cls_002"><span class="cls_002"><?php echo $sensor_120; ?></span></div>
						<div style="position:absolute;left:560px;top:1003.11px" class="cls_002"><span class="cls_002"><?php echo $sensor_119; ?></span></div>
						<div style="position:absolute;left:203.09px;top:1091.85px" class="cls_002"><span class="cls_002"><?php echo $sensor_104; ?></span></div>
						<div style="position:absolute;left:229.16px;top:1091.76px" class="cls_002"><span class="cls_002"><?php echo $sensor_105; ?></span></div>
						<div style="position:absolute;left:253.84px;top:1092.60px" class="cls_002"><span class="cls_002"><?php echo $sensor_106; ?></span></div>
						<div style="position:absolute;left:295.50px;top:1092.60px" class="cls_002"><span class="cls_002"><?php echo $sensor_107; ?></span></div>
						<div style="position:absolute;left:338.00px;top:1091.95px" class="cls_002"><span class="cls_002"><?php echo $sensor_108; ?></span></div>
						<div style="position:absolute;left:363.79px;top:1092.76px" class="cls_002"><span class="cls_002"><?php echo $sensor_109; ?></span></div>
						<div style="position:absolute;left:388.47px;top:1093.85px" class="cls_002"><span class="cls_002"><?php echo $sensor_110; ?></span></div>
						<div style="position:absolute;left:428.03px;top:1091.76px" class="cls_002"><span class="cls_002"><?php echo $sensor_111; ?></span></div>
						<div style="position:absolute;left:452.84px;top:1092.60px" class="cls_002"><span class="cls_002"><?php echo $sensor_112; ?></span></div>
						<div style="position:absolute;left:478.50px;top:1090.85px" class="cls_002"><span class="cls_002"><?php echo $sensor_113; ?></span></div>
						<div style="position:absolute;left:522.78px;top:1090.95px" class="cls_002"><span class="cls_002"><?php echo $sensor_114; ?></span></div>
						<div style="position:absolute;left:547.10px;top:1090.01px" class="cls_002"><span class="cls_002"><?php echo $sensor_115; ?></span></div>
						<div style="position:absolute;left:572.90px;top:1090.01px" class="cls_002"><span class="cls_002"><?php echo $sensor_116; ?></span></div>
						<div style="position:absolute;left:616.12px;top:1089.35px" class="cls_002"><span class="cls_002"><?php echo $sensor_117; ?></span></div>
						<div style="position:absolute;left:641.87px;top:1089.35px" class="cls_002"><span class="cls_002"><?php echo $sensor_118; ?></span></div>

						</div>
		 
                  </div>
              </div>
          </div>
  </div>
</div>


