    <div id="content-wrapper">
        <div class="container-fluid">
    <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
				Parking 3
            </li>
            
          </ol>
			<div class="row">
				<div class="col-md-8">
					<img src="<?php echo base_url()?>images/direction.jpg" style="float:right;">
				</div>
			</div>
			   
          <div class="row">
              <div class="col-ls-12">
                  <div class="card" style="border:0">
						
						<div style="position:absolute;left:45px;top:10px;">
						<img style="margin-bottom: 50px;" src="<?php echo base_url()?>images/floor3.jpg" width=841 height=1190></div>

						<div style="position:absolute;left:171.69px;top:61.48px" class="cls_002"><span class="cls_002"><?php echo $sensor_67; ?></span></div>
						<div style="position:absolute;left:216.02px;top:61.09px" class="cls_002"><span class="cls_002"><?php echo $sensor_66; ?></span></div>
						<div style="position:absolute;left:243.68px;top:61.09px" class="cls_002"><span class="cls_002"><?php echo $sensor_65; ?></span></div>
						<div style="position:absolute;left:470.84px;top:60.59px" class="cls_002"><span class="cls_002"><?php echo $sensor_58; ?></span></div>
						<div style="position:absolute;left:143.50px;top:61.03px" class="cls_002"><span class="cls_002"><?php echo $sensor_68; ?></span></div>
						<div style="position:absolute;left:271.56px;top:61.03px" class="cls_002"><span class="cls_002"><?php echo $sensor_64; ?></span></div>
						<div style="position:absolute;left:314.08px;top:61.45px" class="cls_002"><span class="cls_002"><?php echo $sensor_63; ?></span></div>
						<div style="position:absolute;left:342.86px;top:61.34px" class="cls_002"><span class="cls_002"><?php echo $sensor_62; ?></span></div>
						<div style="position:absolute;left:369.29px;top:61.06px" class="cls_002"><span class="cls_002"><?php echo $sensor_61; ?></span></div>
						<div style="position:absolute;left:413.24px;top:61.28px" class="cls_002"><span class="cls_002"><?php echo $sensor_60; ?></span></div>
						<div style="position:absolute;left:440.59px;top:61.06px" class="cls_002"><span class="cls_002"><?php echo $sensor_59; ?></span></div>
						<div style="position:absolute;left:604.75px;top:126.38px" class="cls_002"><span class="cls_002"><?php echo $sensor_57; ?></span></div>
						<div style="position:absolute;left:566.12px;top:131.47px" class="cls_002"><span class="cls_002"><?php echo $sensor_56; ?></span></div>
						<div style="position:absolute;left:540.11px;top:135.92px" class="cls_002"><span class="cls_002"><?php echo $sensor_55; ?></span></div>
						<div style="position:absolute;left:513.75px;top:139.85px" class="cls_002"><span class="cls_002"><?php echo $sensor_54; ?></span></div>
						<div style="position:absolute;left:470.91px;top:149.72px" class="cls_002"><span class="cls_002"><?php echo $sensor_53; ?></span></div>
						<div style="position:absolute;left:446.06px;top:153.68px" class="cls_002"><span class="cls_002"><?php echo $sensor_52; ?></span></div>
						<div style="position:absolute;left:421.03px;top:158.56px" class="cls_002"><span class="cls_002"><?php echo $sensor_51; ?></span></div>
						<div style="position:absolute;left:351.11px;top:172.11px" class="cls_002"><span class="cls_002"><?php echo $sensor_49; ?></span></div>
						<div style="position:absolute;left:376.92px;top:167.07px" class="cls_002"><span class="cls_002"><?php echo $sensor_50; ?></span></div>
						<div style="position:absolute;left:609.00px;top:168.36px" class="cls_002"><span class="cls_002"><?php echo $sensor_39; ?></span></div>
						<div style="position:absolute;left:325.66px;top:177.47px" class="cls_002"><span class="cls_002"><?php echo $sensor_48; ?></span></div>
						<div style="position:absolute;left:544.90px;top:177.95px" class="cls_002"><span class="cls_002"><?php echo $sensor_40; ?></span></div>
						<div style="position:absolute;left:277.22px;top:185.58px" class="cls_002"><span class="cls_002"><?php echo $sensor_4; ?></span></div>
						<div style="position:absolute;left:520.68px;top:181.63px" class="cls_002"><span class="cls_002"><?php echo $sensor_41; ?></span></div>
						<div style="position:absolute;left:251.32px;top:191.09px" class="cls_002"><span class="cls_002"><?php echo $sensor_3; ?></span></div>
						<div style="position:absolute;left:477.50px;top:190.83px" class="cls_002"><span class="cls_002"><?php echo $sensor_42; ?></span></div>
						<div style="position:absolute;left:704.61px;top:190.79px" class="cls_002"><span class="cls_002"><?php echo $sensor_36; ?></span></div>
						<div style="position:absolute;left:224.53px;top:195.67px" class="cls_002"><span class="cls_002"><?php echo $sensor_2; ?></span></div>
						<div style="position:absolute;left:451.24px;top:196.84px" class="cls_002"><span class="cls_002"><?php echo $sensor_43; ?></span></div>
						<div style="position:absolute;left:426.34px;top:201.66px" class="cls_002"><span class="cls_002"><?php echo $sensor_44; ?></span></div>
						<div style="position:absolute;left:90.09px;top:208.90px" class="cls_002"><span class="cls_002"><?php echo $sensor_69; ?></span></div>
						<div style="position:absolute;left:175.69px;top:206.51px" class="cls_002"><span class="cls_002"><?php echo $sensor_1; ?></span></div>
						<div style="position:absolute;left:383.66px;top:212.45px" class="cls_002"><span class="cls_002"><?php echo $sensor_45; ?></span></div>
						<div style="position:absolute;left:357.59px;top:216.58px" class="cls_002"><span class="cls_002"><?php echo $sensor_46; ?></span></div>
						<div style="position:absolute;left:330.55px;top:222.18px" class="cls_002"><span class="cls_002"><?php echo $sensor_47; ?></span></div>
						<div style="position:absolute;left:709.24px;top:221.53px" class="cls_002"><span class="cls_002"><?php echo $sensor_35; ?></span></div>
						<div style="position:absolute;left:279.63px;top:232.22px" class="cls_002"><span class="cls_002"><?php echo $sensor_8; ?></span></div>
						<div style="position:absolute;left:225.36px;top:240.87px" class="cls_002"><span class="cls_002"><?php echo $sensor_6; ?></span></div>
						<div style="position:absolute;left:252.18px;top:237.01px" class="cls_002"><span class="cls_002"><?php echo $sensor_7; ?></span></div>
						<div style="position:absolute;left:90.84px;top:242.37px" class="cls_002"><span class="cls_002"><?php echo $sensor_70; ?></span></div>
						<div style="position:absolute;left:712.21px;top:253.30px" class="cls_002"><span class="cls_002"><?php echo $sensor_34; ?></span></div>
						<div style="position:absolute;left:90.09px;top:275.44px" class="cls_002"><span class="cls_002"><?php echo $sensor_71; ?></span></div>
						<div style="position:absolute;left:174.69px;top:275.19px" class="cls_002"><span class="cls_002"><?php echo $sensor_5; ?></span></div>
						<div style="position:absolute;left:720.33px;top:302.28px" class="cls_002"><span class="cls_002"><?php echo $sensor_33; ?></span></div>
						<div style="position:absolute;left:91.59px;top:323.23px" class="cls_002"><span class="cls_002"><?php echo $sensor_72; ?></span></div>
						<div style="position:absolute;left:668.30px;top:333.24px" class="cls_002"><span class="cls_002"><?php echo $sensor_38; ?></span></div>
						<div style="position:absolute;left:723.92px;top:331.99px" class="cls_002"><span class="cls_002"><?php echo $sensor_32; ?></span></div>
						<div style="position:absolute;left:621.70px;top:343.81px" class="cls_002"><span class="cls_002"><?php echo $sensor_19; ?></span></div>
						<div style="position:absolute;left:581.72px;top:350.93px" class="cls_002"><span class="cls_002"><?php echo $sensor_18; ?></span></div>
						<div style="position:absolute;left:90.84px;top:355.52px" class="cls_002"><span class="cls_002"><?php echo $sensor_73; ?></span></div>
						<div style="position:absolute;left:555.21px;top:356.77px" class="cls_002"><span class="cls_002"><?php echo $sensor_17; ?></span></div>
						<div style="position:absolute;left:528.20px;top:362.48px" class="cls_002"><span class="cls_002"><?php echo $sensor_16; ?></span></div>
						<div style="position:absolute;left:728.07px;top:362.48px" class="cls_002"><span class="cls_002"><?php echo $sensor_31; ?></span></div>
						<div style="position:absolute;left:481.09px;top:370.25px" class="cls_002"><span class="cls_002"><?php echo $sensor_15; ?></span></div>
						<div style="position:absolute;left:454.56px;top:375.08px" class="cls_002"><span class="cls_002"><?php echo $sensor_14; ?></span></div>
						<div style="position:absolute;left:428.87px;top:381.12px" class="cls_002"><span class="cls_002"><?php echo $sensor_13; ?></span></div>
						<div style="position:absolute;left:91.59px;top:389.83px" class="cls_002"><span class="cls_002"><?php echo $sensor_74; ?></span></div>
						<div style="position:absolute;left:384.41px;top:390.73px" class="cls_002"><span class="cls_002"><?php echo $sensor_12; ?></span></div>
						<div style="position:absolute;left:358.59px;top:397.73px" class="cls_002"><span class="cls_002"><?php echo $sensor_11; ?></span></div>
						<div style="position:absolute;left:331.55px;top:405.22px" class="cls_002"><span class="cls_002"><?php echo $sensor_10; ?></span></div>
						<div style="position:absolute;left:674.75px;top:397.47px" class="cls_002"><span class="cls_002"><?php echo $sensor_37; ?></span></div>
						<div style="position:absolute;left:286.66px;top:415.08px" class="cls_002"><span class="cls_002"><?php echo $sensor_9; ?></span></div>
						<div style="position:absolute;left:732.78px;top:411.78px" class="cls_002"><span class="cls_002"><?php echo $sensor_30; ?></span></div>
						<div style="position:absolute;left:90.09px;top:435.96px" class="cls_002"><span class="cls_002"><?php echo $sensor_75; ?></span></div>
						<div style="position:absolute;left:588.19px;top:432.21px" class="cls_002"><span class="cls_002"><?php echo $sensor_20; ?></span></div>
						<div style="position:absolute;left:736.38px;top:441.55px" class="cls_002"><span class="cls_002"><?php echo $sensor_29; ?></span></div>
						
						
						<div style="position:absolute;left:162.19px;top:454.30px" class="cls_002"><span class="cls_002"><?php echo $sensor_113; ?></span></div>
						<div style="position:absolute;left:245.57px;top:452.30px" class="cls_002"><span class="cls_002"><?php echo $sensor_114; ?></span></div>
						<div style="position:absolute;left:90.84px;top:468.63px" class="cls_002"><span class="cls_002"><?php echo $sensor_76; ?></span></div>
						<div style="position:absolute;left:595.18px;top:467.63px" class="cls_002"><span class="cls_002"><?php echo $sensor_21; ?></span></div>
						<div style="position:absolute;left:740.16px;top:473.37px" class="cls_002"><span class="cls_002"><?php echo $sensor_28; ?></span></div>
						<div style="position:absolute;left:91.59px;top:501.44px" class="cls_002"><span class="cls_002"><?php echo $sensor_77; ?></span></div>
						<div style="position:absolute;left:599.71px;top:502.54px" class="cls_002"><span class="cls_002"><?php echo $sensor_22; ?></span></div>
						<div style="position:absolute;left:748.44px;top:523.12px" class="cls_002"><span class="cls_002"><?php echo $sensor_27; ?></span></div>
						<div style="position:absolute;left:93.28px;top:545.16px" class="cls_002"><span class="cls_002"><?php echo $sensor_78; ?></span></div>
						<div style="position:absolute;left:750.92px;top:553.88px" class="cls_002"><span class="cls_002"><?php echo $sensor_26; ?></span></div>
						<div style="position:absolute;left:161.82px;top:567.44px" class="cls_002"><span class="cls_002"><?php echo $sensor_112; ?></span></div>
						<div style="position:absolute;left:93.28px;top:577.16px" class="cls_002"><span class="cls_002"><?php echo $sensor_79; ?></span></div>
						<div style="position:absolute;left:755.88px;top:584.66px" class="cls_002"><span class="cls_002"><?php echo $sensor_25; ?></span></div>
						<div style="position:absolute;left:697.86px;top:590.75px" class="cls_002"><span class="cls_002"><?php echo $sensor_23; ?></span></div>
						<div style="position:absolute;left:94.03px;top:609.22px" class="cls_002"><span class="cls_002"><?php echo $sensor_80; ?></span></div>
						<div style="position:absolute;left:236.06px;top:575.22px" class="cls_003"><span class="cls_003"></span></div>
						<div style="position:absolute;left:763.88px;top:631.92px" class="cls_002"><span class="cls_002"><?php echo $sensor_24; ?></span></div>
						<div style="position:absolute;left:91.34px;top:655.48px" class="cls_002"><span class="cls_002"><?php echo $sensor_81; ?></span></div>
						<div style="position:absolute;left:311.90px;top:651.48px" class="cls_002"><span class="cls_002"><?php echo $sensor_115; ?></span></div>
						<div style="position:absolute;left:162.94px;top:670.18px" class="cls_002"><span class="cls_002"><?php echo $sensor_111; ?></span></div>
						<div style="position:absolute;left:90.34px;top:685.97px" class="cls_002"><span class="cls_002"><?php echo $sensor_82; ?></span></div>
						<div style="position:absolute;left:315.98px;top:685.50px" class="cls_002"><span class="cls_002"><?php echo $sensor_116; ?></span></div>
						<div style="position:absolute;left:618.25px;top:708.08px" class="cls_002"><span class="cls_002"><?php echo $sensor_139; ?></span></div>
						<div style="position:absolute;left:88.72px;top:718.79px" class="cls_002"><span class="cls_002"><?php echo $sensor_83; ?></span></div>
						<div style="position:absolute;left:623.05px;top:735.44px" class="cls_002"><span class="cls_002"><?php echo $sensor_140; ?></span></div>
						<div style="position:absolute;left:88.22px;top:761.04px" class="cls_002"><span class="cls_002"><?php echo $sensor_84; ?></span></div>
						<div style="position:absolute;left:179.16px;top:761.07px" class="cls_002"><span class="cls_002"><?php echo $sensor_110; ?></span></div>
						<div style="position:absolute;left:773.33px;top:759.25px" class="cls_004"><span class="cls_004" style="color:#fff;">Lift</span></div>
						<div style="position:absolute;left:630.75px;top:782.79px" class="cls_002"><span class="cls_002"><?php echo $sensor_141; ?></span></div>
						<div style="position:absolute;left:88.22px;top:794.16px" class="cls_002"><span class="cls_002"><?php echo $sensor_85; ?></span></div>
						<div style="position:absolute;left:179.16px;top:791.66px" class="cls_002"><span class="cls_002"><?php echo $sensor_109; ?></span></div>
						<div style="position:absolute;left:544.59px;top:796.29px" class="cls_006"><span class="cls_006"><?php echo $sensor_138; ?></span></div>
						<div style="position:absolute;left:519.13px;top:801.79px" class="cls_002"><span class="cls_002"><?php echo $sensor_137; ?></span></div>
						<div style="position:absolute;left:492.34px;top:807.36px" class="cls_002"><span class="cls_002"><?php echo $sensor_136; ?></span></div>
						<div style="position:absolute;left:633.30px;top:809.96px" class="cls_002"><span class="cls_002"><?php echo $sensor_142; ?></span></div>
						<div style="position:absolute;left:447.79px;top:815.57px" class="cls_002"><span class="cls_002"><?php echo $sensor_135; ?></span></div>
						<div style="position:absolute;left:88.22px;top:824.04px" class="cls_002"><span class="cls_002"><?php echo $sensor_86; ?></span></div>
						<div style="position:absolute;left:421.56px;top:822.60px" class="cls_002"><span class="cls_002"><?php echo $sensor_134; ?></span></div>
						<div style="position:absolute;left:177.47px;top:822.54px" class="cls_002"><span class="cls_002"><?php echo $sensor_108; ?></span></div>
						<div style="position:absolute;left:395.47px;top:827.54px" class="cls_002"><span class="cls_002"><?php echo $sensor_133; ?></span></div>
						<div style="position:absolute;left:354.05px;top:835.38px" class="cls_002"><span class="cls_002"><?php echo $sensor_132; ?></span></div>
						<div style="position:absolute;left:635.96px;top:837.35px" class="cls_002"><span class="cls_002"><?php echo $sensor_143; ?></span></div>
						<div style="position:absolute;left:552.11px;top:851.52px" class="cls_002"><span class="cls_002"><?php echo $sensor_123; ?></span></div>
						<div style="position:absolute;left:524.82px;top:854.84px" class="cls_002"><span class="cls_002"><?php echo $sensor_124; ?></span></div>
						<div style="position:absolute;left:498.82px;top:864.91px" class="cls_002"><span class="cls_002"><?php echo $sensor_125; ?></span></div>
						<div style="position:absolute;left:356.48px;top:866.17px" class="cls_002"><span class="cls_002"><?php echo $sensor_130; ?></span></div>
						<div style="position:absolute;left:273.26px;top:873.03px" class="cls_002"><span class="cls_002"><?php echo $sensor_117; ?></span></div>
						<div style="position:absolute;left:454.19px;top:874.91px" class="cls_002"><span class="cls_002"><?php echo $sensor_126; ?></span></div>
						<div style="position:absolute;left:179.16px;top:875.27px" class="cls_002"><span class="cls_002"><?php echo $sensor_107; ?></span></div>
						<div style="position:absolute;left:428.34px;top:880.91px" class="cls_002"><span class="cls_002"><?php echo $sensor_127; ?></span></div>
						<div style="position:absolute;left:80.72px;top:883.79px" class="cls_004"><span class="cls_004" style="color:#fff">Lift</span></div>
						<div style="position:absolute;left:402.45px;top:885.63px" class="cls_002"><span class="cls_002"><?php echo $sensor_128; ?></span></div>
						<div style="position:absolute;left:357.48px;top:897.07px" class="cls_002"><span class="cls_002"><?php echo $sensor_129; ?></span></div>
						<div style="position:absolute;left:178.47px;top:906.54px" class="cls_002"><span class="cls_002"><?php echo $sensor_106; ?></span></div>
						<div style="position:absolute;left:273.26px;top:904.04px" class="cls_002"><span class="cls_002"><?php echo $sensor_118; ?></span></div>
						<div style="position:absolute;left:179.16px;top:937.41px" class="cls_002"><span class="cls_002"><?php echo $sensor_105; ?></span></div>
						<div style="position:absolute;left:272.26px;top:937.05px" class="cls_002"><span class="cls_002"><?php echo $sensor_119; ?></span></div>
						<div style="position:absolute;left:419.64px;top:993.88px" class="cls_002"><span class="cls_002"><?php echo $sensor_120; ?></span></div>
						<div style="position:absolute;left:493.33px;top:994.13px" class="cls_002"><span class="cls_002"><?php echo $sensor_121; ?></span></div>
						<div style="position:absolute;left:561.79px;top:995.38px" class="cls_002"><span class="cls_002"><?php echo $sensor_122; ?></span></div>
						<div style="position:absolute;left:261.70px;top:1035.88px" class="cls_002"><span class="cls_002"><?php echo $sensor_104; ?></span></div>
						<div style="position:absolute;left:305.10px;top:1035.23px" class="cls_002"><span class="cls_002"><?php echo $sensor_103; ?></span></div>
						<div style="position:absolute;left:347.90px;top:1037.23px" class="cls_002"><span class="cls_002"><?php echo $sensor_102; ?></span></div>
						<div style="position:absolute;left:374.27px;top:1036.23px" class="cls_002"><span class="cls_002"><?php echo $sensor_101; ?></span></div>
						<div style="position:absolute;left:400.95px;top:1035.98px" class="cls_002"><span class="cls_002"><?php echo $sensor_100; ?></span></div>
						<div style="position:absolute;left:448.76px;top:1037.23px" class="cls_002"><span class="cls_002"><?php echo $sensor_99; ?></span></div>
						<div style="position:absolute;left:475.91px;top:1037.02px" class="cls_002"><span class="cls_002"><?php echo $sensor_98; ?></span></div>
						<div style="position:absolute;left:503.22px;top:1037.63px" class="cls_002"><span class="cls_002"><?php echo $sensor_97; ?></span></div>
						<div style="position:absolute;left:542.27px;top:1034.63px" class="cls_002"><span class="cls_002"><?php echo $sensor_96; ?></span></div>
						<div style="position:absolute;left:569.29px;top:1035.63px" class="cls_002"><span class="cls_002"><?php echo $sensor_95; ?></span></div>
						<div style="position:absolute;left:711.11px;top:1066.11px" class="cls_005"><span class="cls_005">VX Office</span></div>
						<div style="position:absolute;left:365.38px;top:1124.57px" class="cls_002"><span class="cls_002"><?php echo $sensor_87; ?></span></div>
						<div style="position:absolute;left:457.66px;top:1122.67px" class="cls_002"><span class="cls_002"><?php echo $sensor_90; ?></span></div>
						<div style="position:absolute;left:485.99px;top:1123.74px" class="cls_002"><span class="cls_002"><?php echo $sensor_91; ?></span></div>
						<div style="position:absolute;left:512.49px;top:1123.74px" class="cls_002"><span class="cls_002"><?php echo $sensor_92; ?></span></div>
						<div style="position:absolute;left:556.11px;top:1122.07px" class="cls_002"><span class="cls_002"><?php echo $sensor_93; ?></span></div>
						<div style="position:absolute;left:582.86px;top:1122.07px" class="cls_002"><span class="cls_002"><?php echo $sensor_94; ?></span></div>
						<div style="position:absolute;left:392.94px;top:1124.41px" class="cls_002"><span class="cls_002"><?php echo $sensor_88; ?></span></div>
						<div style="position:absolute;left:419.69px;top:1124.16px" class="cls_002"><span class="cls_002"><?php echo $sensor_89; ?></span></div>
						<div style="position:absolute;left:449.62px;top:1129.50px" class="cls_003"><span class="cls_003"></span></div>

						</div>
		 
                  </div>
              </div>
          </div>
  </div>
</div>


